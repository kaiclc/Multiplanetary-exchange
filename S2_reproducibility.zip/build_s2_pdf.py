from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, Paragraph, Table, TableStyle, Spacer, PageBreak
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont("DejaVu", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DejaVu-Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFontFamily("DejaVu",normal="DejaVu",bold="DejaVu-Bold",italic="DejaVu",boldItalic="DejaVu-Bold")

OUT=Path('output/S2/S2_appendix.pdf')
body=ParagraphStyle('body',fontName='DejaVu',fontSize=10,leading=11.4,spaceAfter=3)
heading=ParagraphStyle('heading',parent=body,fontName='DejaVu-Bold',fontSize=11.2,leading=13,spaceBefore=6,spaceAfter=4)
title=ParagraphStyle('title',parent=heading,fontSize=16,leading=18)
cell=ParagraphStyle('cell',parent=body,fontSize=10,leading=11,spaceAfter=0)
story=[]
def p(s,style=body):story.append(Paragraph(s,style))
def table(rows,widths):
    cells=[[Paragraph(escape(str(v)),cell) for v in row] for row in rows]
    t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e9eef4')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),2.5),('BOTTOMPADDING',(0,0),(-1,-1),2.5),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#8192a3')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d1d9e2'))]))
    story.append(t);story.append(Spacer(1,5))
p('S2: Earth isolation during settlement',title)
p('Gator Quant Hacks | Evidence appendix | Hours from the supplied epoch')
p('Scenario and incident selection',heading)
p('Retain the accepted 11-institution design. Each run resets to $220,000 and 1,200 AH shares in the same five client accounts; institutions start at zero. Only the Belt Metal Future is active: Mars long, Ceres short, 10 lots, multiplier 100, entry 100, maturity h480. C_Ceres publishes 100, 120, 125 at h0, h240, h480. Total payout is $25,000; the interim $20,000 mark is a backed allocation, not an additional payment. Initial margins are $25,000 each; the loser tops up $20,000.')
p('<b>Incident: Earth gateway isolation, Node 3, [h482.750, h554.750).</b> Both relay channels fail for emissions touching Earth. Local access and durable records survive. The exchange has no advance notice of the incident or restoration.')
p('We tested 5,556 starts/configurations: all nine isolation locations, all 11 forced-loss nodes and all 11 institution resets on a six-hour h0-h480 grid; then minute starts in h470-h485 and emission boundaries within 1 ms for Earth/Mars/Ceres isolation. Earth and Ceres tie at h560.9253; Earth has higher encumbrance, 33.925 versus 30.094 million dollar-hours, and affects both clearing channels. Mars reaches h560.6533. The worst coarse forced-loss case reaches h509.0837. Earth is the worst tested case, rather than a continuous-time optimality proof.')
p('Trace: financial state and local knowledge',heading)
table([
['Hour','Actor / action','Financial consequence'],
['0.5657','Clearing has both locks','Position open; $50,000 margin.'],
['241.6241','Clearing receives mark','Short liability $20,000; equity $5,000 triggers call.'],
['266.0015 / 266.5415','Ceres receives call / clearing confirms top-up','Top-up locks one second after receipt; total margin $70,000.'],
['481.5842','Clearing receives final price','Discharge; Mars owns $25,000 backed claim.'],
['482.750 / 483.1344 / 483.2192','Isolation / returning SYN-ACKs arrive','Emitted before isolation, they survive. Earth emits ACKs and data; those launches fail.'],
['554.750','Connectivity restored','No financial release; existing timers continue.'],
['559.7591 / 560.1080','Clearing receives fourth SYN-ACKs','Final ACKs sent; fourth data attempts emit at h559.7669 / h560.1130.'],
['560.5337 / 560.9253','Mars / Ceres apply ordered data','Winner receives spendable funds; loser records debit and releases residual margin. Both complete.']
],[66,145,257])
p('<b>Lost service:</b> physical isolation 72 h. First financial service resumes at h560.5337, 5.7837 h after reconnection. Full recovery is <b>h560.9253</b>: 6.1753 h after reconnection, 78.1753 h after onset, and <b>76.8883 h later than baseline</b> h484.0370. The backed claim waits 79.3411 h from discharge. Packet receipt alone is not recovery.')
story.append(PageBreak())
p('S2: obligations, comparisons, and checks',title)
p('Every obligation remains funded',heading)
table([
['Obligation','State throughout isolation','Recovery'],
['Futures payment','Discharged at clearing; Mars owns $25,000 claim backed by Ceres collateral, unavailable locally. Interim mark counted once.','Mars credit h560.5337.'],
['Margin returns','Mars $25,000; Ceres residual $20,000 unavailable. Stale local locks mirror the same backing.','Release at each local settlement update.'],
['Top-up / default','Top-up already confirmed. Receipt-based 24 h deadline satisfied; no further call or default.','No unbacked obligation.'],
['Fee','Conditional $10 fee unpaid during isolation.','Winner pays from proceeds h560.5337.']
],[86,266,116])
p('Isolation balances: Earth_Investor $100,000, Mars_Seller $0, Mars_Factory $25,000, Ceres_Miner $5,000, Neptune_Saver $20,000. Available $150,000 + unique locks $70,000 = $220,000. Peak <b>31.818%</b>; 1,200 shares unchanged. No other obligations; locks survive silence.')
p('Final cash: Earth $100,000; seller $0; Mars <b>$74,990</b>; Ceres <b>$25,000</b>; Neptune $20,000; clearing $10. Locks clear; total $220,000. Ceres loss $25,000; extra encumbrance 5,368,966.91 dollar-hours.')
p('Maintenance removed: identical geometry and incident',heading)
table([
['Metric','Baseline','Stress + maint.','Stress, no maint.'],
['Margin-call receipt (h)','266.0015','266.0015','244.1198'],
['Discharge / claim (h)','481.5842','481.5842','481.5842'],
['Full completion (h)','484.0370','560.9253','560.9253'],
['Million dollar-hours','28.556','33.925','34.363'],
['Origins / launches','16 / 156','16 / 226','16 / 226'],
],[152,99,109,108])
p('Without maintenance, the call arrives <b>21.8817 h earlier</b>; recovery and balances match. Earlier top-up adds 437,634.00 dollar-hours. Feed uses A; call uses B-Ceres. B-Neptune has no traffic.')
p('Sensitivity: reverse the price path',heading)
p('Prices become <b>100 -&gt; 80 -&gt; 75</b>; funding, guarantees and incident stay identical. Mars tops up and pays Ceres $25,000. Full completion is <b>h560.9256</b>, versus falling baseline h484.0373: 76.8883 h extra. Mars/Ceres finish at $25,000/$74,990; fee $10, peak locks $70,000. Traffic: 17 origins / 238 launches, versus 17 / 168 unstressed. Both directions recover.')
p('Conditions and reproducibility',heading)
p('Conditional traces suppress background random loss, retain incident loss and log launch probabilities. Official Kepler geometry includes moving receivers; tolerance below 1 ms. Counted sessions begin h-4; no keepalives, so h240/h480 require fresh handshakes. Feed/top-up records use A; clearing calls/settlement use B. Local handoffs: 1 s. Default uses actual posted equity after top-up; winner pays fee. Choices apply to every run.')
p('Stress: 56 forced failed launches, 14 abandoned hop copies, zero Direct packets, at most six origins/24 h, queue four, window two. Independent trace checks pass conservation, capacity, closures, incident timing, retry caps and capital integration. No saturated-demand or stochastic-deadline guarantee is inferred. Sources: brief Sections 5, 6, 8; design Sections 3-5, 8. Code, inputs and traces accompany this appendix.')
def footer(canvas,doc):
    canvas.setFont('DejaVu',10);canvas.setFillColor(colors.HexColor('#56677a'));canvas.drawString(72,47,'S2 | Conditional stress evidence');canvas.drawRightString(540,47,str(doc.page))
doc=BaseDocTemplate(str(OUT),pagesize=letter,leftMargin=72,rightMargin=72,topMargin=72,bottomMargin=72,title='S2: Earth isolation during futures settlement',author='Gator Quant Hacks team')
doc.addPageTemplates(PageTemplate(id='S2',frames=[Frame(72,72,468,648,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=footer))
doc.build(story)
print(OUT)
