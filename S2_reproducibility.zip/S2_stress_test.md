# S2: Earth isolation during futures settlement

**Gator Quant Hacks | Evidence appendix | Hours measured from the supplied epoch**

## Scenario and selection

We retain the 11-institution design and its funding and guarantees, taking the earlier review concerns as accepted under the team's instruction. Every run resets to the same five client accounts: $220,000 and 1,200 AH shares; institutions start with zero. Only the Belt Metal Future is active: Mars_Factory is long 10 lots, Ceres_Miner short 10, multiplier 100, entry 100, maturity h480. C_Ceres publishes 100, 120, 125 at h0, h240, h480. Total payoff is $25,000; the interim $20,000 mark is a backed allocation within collateral, not another payment. Each side initially locks $25,000; the loser adds $20,000 after the interim margin call.

We choose **72-hour gateway isolation of Earth, Node 3, during [h482.750, h554.750)**. This disables emissions touching Earth through both relays; local access and durable financial records survive. The incident is unannounced: the exchange follows its ordinary retry procedure and has no advance notice of restoration.

Selection used 5,556 candidate runs: all nine gateway isolations, forced loss at all 11 nodes, and resets at all 11 institution endpoints, starting every six hours from h0 through h480; then Earth/Mars/Ceres isolation starts every minute during h470-h485 and within 1 ms of baseline emissions. Earth and Ceres tie for latest completion, h560.9253; Earth locks 33.925 million dollar-hours versus Ceres' 30.094 million. Mars' worst refined completion is h560.6533. Earth also disrupts both clearing channels. The six-hour forced-loss scan's worst completion is h509.0837. This is the worst tested case, not a proof over all continuous start times.

## Trace and financial recovery

| Hour | Actor and local knowledge | Action / financial state |
| --- | --- | --- |
| 0.5657 | C_Earth has both funded order records | Position opens; $50,000 margin locked. |
| 241.6241 | C_Earth receives the h240 observation | $20,000 short liability backed; short equity $5,000 triggers a call. |
| 266.0015 / 266.5415 | Ceres receives call / clearing receives top-up record | Ceres locks $20,000 one second after receipt; posted margins become $45,000 short, $25,000 long. |
| 480 / 481.5842 | Maturity / final observation reaches clearing | Contract discharged; Mars owns a $25,000 backed claim; $70,000 remains unavailable. |
| 482.750 | Incident starts; endpoints have no advance notice | Both returning SYN-ACKs were emitted toward Earth before isolation and remain in flight. |
| 483.1344 / 483.2192 | C_Earth receives those SYN-ACKs | It emits final ACKs and settlement data; Earth-touching launches fail. Receipts prove no settlement. |
| 554.750 | Connectivity returns, unknown to applications | No financial release occurs; existing retry timers continue. |
| 559.7591 / 560.1080 | C_Earth receives fourth SYN-ACK attempts | Final ACKs are sent; fourth data attempts emit at h559.7669 / h560.1130. |
| 560.5337 / 560.9253 | Mars / Ceres receive ordered settlement data | Mars credits usable proceeds and releases its margin; Ceres records the matching debit and releases residual margin. Both sides complete at h560.9253. |

Physical isolation lasts **72 h**. First financial service resumes at h560.5337, **5.7837 h after reconnection**. Full settlement recovery takes **6.1753 h after reconnection**, or **78.1753 h from incident onset**. Relative to the unstressed completion h484.0370, settlement loses **76.8883 h**. The backed claim waits 79.3411 h from discharge to full completion. Transport acknowledgments alone are not recovery.

<!-- PAGE BREAK -->

## Obligations, balances, and safety

Throughout the incident, the future is already discharged at the authoritative ledger. Its settlement obligations remain funded:

| Obligation | State during [h482.750, h554.750) | Resolution |
| --- | --- | --- |
| Final futures payment | Mars owns $25,000 backed by Ceres collateral; not spendable. Interim mark is included once. | Mars credit at h560.5337. |
| Margin returns | Mars $25,000; Ceres residual $20,000 remain encumbered. | Released at their respective local settlement updates. |
| Interim top-up | $20,000 already posted and recorded; receipt-based 24 h deadline satisfied. | No further call or default. |
| Clearing fee | $10 conditional on settlement; unpaid during isolation. | Winner pays from proceeds at h560.5337. |

All local stale lock records remain unavailable until settlement instructions arrive; they are mirrors of the same backing, not extra assets. No lock expires on silence, no new endowment appears, and no collateral funds two obligations. There are no equity trades, transfers, or other live obligations in this reset run. Inactive clients and all 1,200 shares remain unchanged.

| Account | Available during incident | Encumbered backing / claim | Final spendable |
| --- | ---: | ---: | ---: |
| Earth_Investor | $100,000 | $0 | $100,000 |
| Mars_Seller | $0 | $0 | $0 |
| Mars_Factory | $25,000 | $25,000 margin + $25,000 claim | $74,990 |
| Ceres_Miner | $5,000 | $20,000 residual margin | $25,000 |
| Neptune_Saver | $20,000 | $0 | $20,000 |
| C_Earth fee reserve | $0 | $0 | $10 |

Available cash ($150,000) plus unique encumbered backing/claims ($70,000) equals $220,000 during isolation; final spendable cash is $220,000. Peak encumbrance is **31.818%**. The rising path's realized loss is Ceres' $25,000; no loss is unbacked. Extra encumbrance versus the unstressed run is **5,368,966.91 dollar-hours**.

## Maintenance comparison and sensitivity

Natural geometry, incident, funding, guarantees, and retry rules are identical in the maintenance comparison. Both scheduled windows are removed in the second run.

| Metric | Baseline | Stress + maintenance | Stress, maintenance removed |
| --- | ---: | ---: | ---: |
| Margin-call receipt (h) | 266.0015 | 266.0015 | 244.1198 |
| Discharge / backed claim (h) | 481.5842 | 481.5842 | 481.5842 |
| Full spendable completion (h) | 484.0370 | 560.9253 | 560.9253 |
| Encumbrance (million dollar-hours) | 28.556 | 33.925 | 34.363 |
| Origins / backbone launches | 16 / 156 | 16 / 226 | 16 / 226 |

Removing B-Ceres maintenance delivers the call **21.8817 h earlier** but leaves recovery unchanged. It increases encumbrance by **437,634.00 dollar-hours**, because the same $20,000 top-up locks earlier. The price feed uses Relay A, so maintenance does not delay the final observation. B-Neptune maintenance has no traffic in this scenario.

The sensitivity changes only prices to **100 -> 80 -> 75**, retaining the identical Earth incident, balances, and guarantees. Mars posts the top-up and pays Ceres $25,000. Completion is **h560.9256** versus its unstressed h484.0373: again **76.8883 h** extra. Final Mars/Ceres balances are $25,000/$74,990, with the same $10 fee and $70,000 peak encumbrance. Traffic is 17 origins and 238 launches versus 17/168 unstressed. Recovery survives reversal of the losing party.

**Reproducibility and conditions.** These are conditional traces: background random losses are suppressed, incident losses retained; each launch logs its distance-dependent loss probability. Moving-receiver Kepler geometry uses the official frozen inputs and light-time convergence below 1 ms. Sessions pre-established at h-4 are counted; no keepalives are assumed, so h240/h480 traffic includes fresh handshakes after seven-day expiry. Price traffic/top-up records use Relay A; clearing calls/settlement use Relay B. Accepted local handoffs take one second. Standard-run default evaluation uses actual posted equity after top-up; the winner pays the unspecified $10 fee. These declared implementation choices apply identically to comparisons. The stress has 56 forced failed launches, 14 abandoned hop copies, zero Direct packets, maximum six origins/24 h, queue four, and window two. Independent exported-trace checks passed cash conservation, capacity, maintenance, incident timing, retry caps, and capital integration. This measures one funded contract, not saturated-market throughput or a stochastic deadline guarantee. Supporting sources: participant brief Sections 5, 6, 8; accepted design Sections 3-5, 8.
