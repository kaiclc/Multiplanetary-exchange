"""Independent checks on exported S2 traces; stdlib only."""
import collections, csv, json, math, pathlib, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'results')
summary = json.loads((root/'summary.json').read_text())
checked = {}
for name, result in summary.items():
    if not isinstance(result, dict) or 'spendable_hour' not in result:
        continue
    states = json.loads((root/(name+'_financial.json')).read_text())
    launches = list(csv.DictReader((root/(name+'_launches.csv')).open()))
    events = json.loads((root/(name+'_events.json')).read_text())
    integral = 0
    for index, state in enumerate(states):
        total = sum(state['available_cash'].values())+sum(state['margin'].values())+state['unspent_backed_claim']
        assert total == 220000, (name, 'cash conservation', state)
        assert min(list(state['available_cash'].values())+list(state['margin'].values())+[state['unspent_backed_claim']]) >= 0
        next_hour = states[index+1]['hour'] if index+1<len(states) else result['spendable_hour']
        integral += state['encumbered_cash']*(next_hour-state['hour'])
    assert abs(integral-result['asset_hours_cash']) < 1e-5, (name, 'capital integral')
    links = collections.defaultdict(list)
    failures = 0
    for row in launches:
        emission, arrival = float(row['emission_hour']), float(row['arrival_hour'])
        assert arrival > emission
        assert float(row['clearance_au']) >= .1
        assert abs(float(row['loss_probability'])-(1-math.exp(-.02*float(row['distance_au'])))) < 1e-12
        assert 0 <= int(row['hop_launch']) <= 4 and 0 <= int(row['endpoint_attempt']) <= 4
        links[(row['sender'], row['receiver'])].append(emission*3600)
        if result['maintenance']:
            for endpoints, lo, hi in [({'Relay B','Neptune'},2,26),({'Relay B','Ceres'},240,264)]:
                assert not ({row['sender'],row['receiver']}==endpoints and emission < hi and arrival >= lo)
        incident = result['incident']
        forced = bool(incident and incident['kind']!='reset' and incident['start']<=emission<incident['start']+incident['duration'] and incident['node'] in (row['sender'],row['receiver']))
        assert (row['forced_loss']=='True') == forced
        failures += forced
    for times in links.values():
        assert all(b-a >= 1-1e-6 for a,b in zip(times,times[1:])), (name,'link capacity')
    origins = [e for e in events if e['kind']=='origination']
    assert len(origins)==result['originated_backbone_packets']
    max_rolling = max(sum(e['hour']-24<x['hour']<=e['hour'] for x in origins) for e in origins)
    assert max_rolling == result['max_rolling24_origins'] <= 600
    assert result['direct_packets']==0
    assert len(launches)==result['total_backbone_launches'] and failures==result['forced_loss_launches']
    assert result['max_queue_packets']<=10000 and result['max_unacknowledged_data']<=64
    assert result['spendable_hour']==max(result['winner_notice'],result['loser_notice'])
    assert states[-1]['position']=='complete' and states[-1]['encumbered_cash']==0
    assert sum(result['final_cash'].values())==220000
    checked[name]={'passed':True,'financial_states':len(states),'launches':len(launches),'independent_asset_hours':integral,'max_rolling24_origins':max_rolling}
assert summary['stress']['final_cash']==summary['stress_no_maintenance']['final_cash']==summary['baseline']['final_cash']
assert summary['stress']['spendable_hour']==summary['stress_no_maintenance']['spendable_hour']
assert summary['stress_falling']['peak_encumbered_cash']==summary['stress']['peak_encumbered_cash']==70000
print(json.dumps(checked,indent=2))
