"""Reproducible S2 event simulation for the accepted hub/gateway paper.
Python standard library only. Times internally seconds; output hours.
Run: python3 s2_simulation.py --data PATH --output PATH [--scan]
Conditional runs remove background random loss but retain incident-forced loss.
"""
import argparse, collections, csv, heapq, itertools, json, math, pathlib

NAMES=['Mercury','Venus','Earth','Mars','Ceres','Jupiter','Saturn','Uranus','Neptune','Relay A','Relay B']
NODE={n:i+1 for i,n in enumerate(NAMES)}
END_NODE={f'O_{n}':n for n in NAMES[:9]}|{'C_Earth':'Earth','C_Ceres':'Ceres'}

class Geometry:
 def __init__(self,data):
  self.bodies={b['name']:b for b in json.loads((data/'orbital_elements.json').read_text())['bodies']+json.loads((data/'network_model.json').read_text())['relays']}
 def pos(self,name,t):
  b=self.bodies[name];a,e=b['a_au'],b['e'];M=math.radians((b['mean_anomaly_deg']+b['mean_motion_deg_day']*t/86400)%360);E=M
  for _ in range(30):
   delta=(E-e*math.sin(E)-M)/(1-e*math.cos(E));E-=delta
   if abs(delta)<1e-14:break
  x=a*(math.cos(E)-e);y=a*math.sqrt(1-e*e)*math.sin(E);w,i,O=[math.radians(b[k]) for k in ['arg_peri_deg','i_deg','node_deg']]
  x1=x*math.cos(w)-y*math.sin(w);y1=x*math.sin(w)+y*math.cos(w)
  return (x1*math.cos(O)-y1*math.cos(i)*math.sin(O),x1*math.sin(O)+y1*math.cos(i)*math.cos(O),y1*math.sin(i))
 def flight(self,s,r,e):
  x=self.pos(s,e);a=e
  for _ in range(20):
   y=self.pos(r,a);new=e+8.317*60*math.dist(x,y)
   if abs(new-a)<0.00001:a=new;break
   a=new
  y=self.pos(r,a);v=tuple(y[j]-x[j] for j in range(3));v2=sum(k*k for k in v);u=max(0,min(1,-sum(x[j]*v[j] for j in range(3))/v2)) if v2 else 0
  clearance=math.sqrt(sum((x[j]+u*v[j])**2 for j in range(3)))
  return a,(a-e)/(8.317*60),clearance
 def route_delay(self,route,t):
  start=t
  for k in range(len(route)-1):
   t=self.flight(route[k],route[k+1],t+1)[0]
   if k<len(route)-2:t+=1
  return t-start

class Sim:
 def __init__(self,g,incident=None,maintenance=True,direction='up',detail=False):
  self.g=g;self.incident=incident;self.maintenance=maintenance;self.direction=direction;self.detail=detail;self.events=[];self.serial=itertools.count();self.t=-4*3600;self.packets=itertools.count(1);self.sessions=itertools.count(1);self.sequence=collections.Counter();self.links={};self.conn={};self.all_conn=[];self.seen=set();self.origins=[];self.launches=[];self.logs=[];self.fin=[];self.metrics={};self.max_queue=0;self.max_window=0;self.disconnected=False;self.total_launch=0;self.forced_losses=0;self.abandoned=0
  self.cash={'Earth_Investor':100000,'Mars_Seller':0,'Mars_Factory':50000,'Ceres_Miner':50000,'Neptune_Saver':20000,'C_Earth_fee':0};self.margin={'Mars_Factory':0,'Ceres_Miner':0};self.claim=0;self.position='not_open';self.order_locks=set();self.loser='Ceres_Miner' if direction=='up' else 'Mars_Factory';self.winner='Mars_Factory' if direction=='up' else 'Ceres_Miner';self.last_asset_time=0;self.asset_hours=0;self.peak=0;self.notifications=set();self.run_end=650*3600
 def at(self,t,fn,*args,priority=50):heapq.heappush(self.events,(t,priority,next(self.serial),fn,args))
 def log(self,kind,actor,**kw):
  if self.detail:self.logs.append({'hour':self.t/3600,'kind':kind,'actor':actor,**kw})
 def state(self,event):
  if self.t>=0:
   locked=sum(self.margin.values())+self.claim
   self.asset_hours+=(self.t-self.last_asset_time)/3600*(sum(self.margin.values())+self.claim)
   self.last_asset_time=self.t;self.peak=max(self.peak,locked)
  assert abs(sum(self.cash.values())+sum(self.margin.values())+self.claim-220000)<1e-8
  assert all(v>=0 for v in list(self.cash.values())+list(self.margin.values())+[self.claim])
  self.fin.append({'hour':self.t/3600,'event':event,'position':self.position,'available_cash':dict(self.cash),'margin':dict(self.margin),'unspent_backed_claim':self.claim,'encumbered_cash':sum(self.margin.values())+self.claim})
 def change(self,fn,event):
  if self.t>=0:
   self.asset_hours+=(self.t-self.last_asset_time)/3600*(sum(self.margin.values())+self.claim);self.last_asset_time=self.t
  fn();self.state(event)
 def origin(self,kind,src):
  self.origins.append((self.t,kind,src));recent=sum(t>self.t-86400 for t,_,_ in self.origins)
  assert recent<=600;self.log('origination',src,message=kind,rolling24_count=recent)
 def usable_emit(self,s,r,ready):
  e=ready+1
  for _ in range(20000):
   a,d,c=self.g.flight(s,r,e)
   if c<.1:e+=600;continue
   bad=None
   if self.maintenance:
    for x,y,lo,hi in [('Relay B','Neptune',2*3600,26*3600),('Relay B','Ceres',240*3600,264*3600)]:
     if {s,r}=={x,y} and e<hi and a>=lo:bad=hi;break
   if bad is not None:e=bad;continue
   return e,a,d,c
  raise RuntimeError('contact search exhausted')
 def forced(self,s,r,e):
  if not self.incident or self.incident['kind']=='reset':return False
  return self.incident['start']*3600<=e<(self.incident['start']+self.incident['duration'])*3600 and self.incident['node'] in (s,r)
 def queue(self,s,r,item):
  link=self.links.setdefault((s,r),{'q':collections.deque(),'busy':False})
  if len(link['q'])>=10000:self.log('queue_drop',s,receiver=r);return
  link['q'].append(item);self.max_queue=max(self.max_queue,len(link['q']))
  if not link['busy']:self.schedule_link(s,r)
 def schedule_link(self,s,r):
  link=self.links[(s,r)]
  while link['q'] and not self.item_live(link['q'][0]):link['q'].popleft()
  if not link['q']:link['busy']=False;return
  link['busy']=True;item=link['q'][0];e,a,d,c=self.usable_emit(s,r,self.t)
  self.at(e,self.emit,s,r,item,a,d,c,priority=30+NODE[s])
 def item_live(self,item):
  if item['receipt']:return True
  tr=item['transfer'];op=tr['packet']['op']
  return not tr['acked'] and not tr['abandoned'] and not tr.get('superseded',False) and not op['conn']['dead'] and self.t<op['created']+30*86400
 def emit(self,s,r,item,a,d,c):
  link=self.links[(s,r)];assert link['q'][0] is item;link['q'].popleft();link['busy']=False
  if not self.item_live(item):self.schedule_link(s,r);return
  lost=self.forced(s,r,self.t);self.total_launch+=1;self.forced_losses+=int(lost);self.sequence[s]+=1
  row={'emission_hour':self.t/3600,'sender':s,'receiver':r,'arrival_hour':a/3600,'distance_au':d,'loss_probability':1-math.exp(-.02*d),'forced_loss':lost,'clearance_au':c,'kind':'HOP_RECEIPT' if item['receipt'] else item['transfer']['packet']['op']['kind'],'packet_id':item['packet_id'],'hop_launch':0 if item['receipt'] else item['transfer']['launches']+1,'endpoint_attempt':0 if item['receipt'] else item['transfer']['packet']['attempt']}
  if self.detail:self.launches.append(row)
  self.log('launch',s,transmission=row)
  if item['receipt']:
   if not lost:self.at(a,self.receipt_arrive,item['target'],priority=NODE[s])
  else:
   tr=item['transfer'];tr['launches']+=1;tr['launched']=True
   if not lost:self.at(a,self.hop_arrive,tr,priority=NODE[s])
   self.at(self.t+2*(a-self.t)+3600,self.hop_timeout,tr,priority=100)
  self.schedule_link(s,r)
 def receipt_arrive(self,tr):
  tr['acked']=True;self.log('hop_receipt',tr['route'][tr['index']],packet_id=tr['packet']['id'])
 def hop_timeout(self,tr):
  if tr['acked'] or tr['abandoned'] or tr['packet']['op']['conn']['dead']:return
  if tr['launches']>=4:
   tr['abandoned']=True;self.abandoned+=1;self.log('hop_abandoned',tr['route'][tr['index']],packet_id=tr['packet']['id']);return
  self.enqueue_hop(tr)
 def enqueue_hop(self,tr):
  s,r=tr['route'][tr['index']:tr['index']+2]
  self.queue(s,r,{'receipt':False,'transfer':tr,'packet_id':tr['packet']['id']})
 def send_route(self,packet,route):
  tr={'packet':packet,'route':route,'index':0,'launches':0,'acked':False,'abandoned':False,'launched':False};packet['transfers'].append(tr);self.enqueue_hop(tr)
 def hop_arrive(self,tr):
  packet=tr['packet'];op=packet['op'];s,r=tr['route'][tr['index']:tr['index']+2]
  self.queue(r,s,{'receipt':True,'target':tr,'packet_id':packet['id']})
  key=(r,packet['id'])
  if key in self.seen:return
  self.seen.add(key)
  if tr['index']<len(tr['route'])-2:
   nt={'packet':packet,'route':tr['route'],'index':tr['index']+1,'launches':0,'acked':False,'abandoned':False,'launched':False};packet['transfers'].append(nt);self.at(self.t+1,self.enqueue_hop,nt)
  elif not op['conn']['dead']:self.endpoint_receive(op,packet)
 def operation(self,c,kind,src,dst,callback=None,seq=None,quota=False):
  op={'conn':c,'kind':kind,'src':src,'dst':dst,'callback':callback,'seq':seq,'attempts':0,'done':False,'created':self.t,'copies':[]}
  if quota:self.origin(kind,src)
  self.attempt(op);return op
 def attempt(self,op):
  if op['done'] or op['conn']['dead']:return
  if op['attempts']>=4:
   op['done']=True;self.log('endpoint_exhausted',op['src'],message=op['kind']);self.at(self.t+1,self.recover,op['conn']);return
  for packet in op['copies']:
   for tr in packet['transfers']:
    if not tr['launched']:tr['superseded']=True
  op['attempts']+=1;c=op['conn'];route=c['route'] if op['src']==c['src'] else list(reversed(c['route']));T0=self.g.route_delay(route,self.t);packet={'id':next(self.packets),'op':op,'attempt':op['attempts'],'transfers':[]};op['copies'].append(packet)
  self.log('endpoint_enqueue',op['src'],message=op['kind'],attempt=op['attempts'],retry_timer_hours=(2*T0+86400)/3600,session=c['id']);self.send_route(packet,route)
  if op['kind'] in ('SYN','SYN_ACK','DATA'):self.at(self.t+2*T0+86400,self.endpoint_timeout,op,priority=120)
 def endpoint_timeout(self,op):
  if not op['done'] and not op['conn']['dead']:self.attempt(op)
 def new_conn(self,src,dst,relay):
  c={'id':next(self.sessions),'src':src,'dst':dst,'route':[END_NODE[src],relay,END_NODE[dst]],'ready':False,'released':False,'dead':False,'last_rx':{src:self.t,dst:self.t},'pending':[],'buffer':{},'next_send':0,'next_receive':0,'data_ops':{},'unacked':0,'synack':None}
  self.conn[(src,dst,relay)]=c;self.all_conn.append(c);c['syn']=self.operation(c,'SYN',src,dst,quota=True);return c
 def get_conn(self,src,dst,relay):
  c=self.conn.get((src,dst,relay))
  if c and (c['dead'] or any(self.t-t>=7*86400 for t in c['last_rx'].values())):
   c['dead']=True;c=None
  return c or self.new_conn(src,dst,relay)
 def send_app(self,src,dst,relay,label,callback):
  c=self.get_conn(src,dst,relay);record={'src':src,'dst':dst,'relay':relay,'label':label,'callback':callback,'applied':False}
  c['pending'].append(record);self.flush(c)
 def flush(self,c):
  if not c['ready'] or c['dead']:return
  while c['pending'] and c['unacked']<64:
   record=c['pending'].pop(0);seq=c['next_send'];c['next_send']+=1;c['unacked']+=1;self.max_window=max(self.max_window,c['unacked']);op=self.operation(c,'DATA',c['src'],c['dst'],record,seq,quota=True);c['data_ops'][seq]=op
 def endpoint_receive(self,op,packet):
  c=op['conn'];dst=op['dst'];c['last_rx'][dst]=self.t;self.log('endpoint_receive',dst,message=op['kind'],session=c['id'],attempt=packet['attempt'])
  if op['kind']=='SYN':
   if c['synack'] is None:c['synack']=self.operation(c,'SYN_ACK',c['dst'],c['src'])
   elif not c['synack']['done'] and c['synack']['attempts']<4:self.attempt(c['synack'])
  elif op['kind']=='SYN_ACK':
   c['syn']['done']=True;c['ready']=True;self.operation(c,'ACK',c['src'],c['dst']);self.flush(c)
  elif op['kind']=='ACK':
   if c['synack']:c['synack']['done']=True
   c['released']=True;self.release_data(c)
  elif op['kind']=='DATA':
   self.operation(c,'DATA_ACK',c['dst'],c['src'],callback=op)
   if op['seq']>=c['next_receive']:c['buffer'][op['seq']]=op
   if c['released']:self.release_data(c)
  elif op['kind']=='DATA_ACK':
   target=op['callback']
   if not target['done']:target['done']=True;c['unacked']-=1;self.flush(c)
 def release_data(self,c):
  while c['next_receive'] in c['buffer']:
   op=c['buffer'].pop(c['next_receive']);c['next_receive']+=1;record=op['callback']
   if not record['applied']:
    record['applied']=True;self.log('application_delivery',op['dst'],message=record['label']);record['callback']()
 def recover(self,c):
  if c['dead']:return
  c['dead']=True
  records=list(c['pending'])+[op['callback'] for op in c['data_ops'].values() if not op['callback']['applied']]
  for r in records:self.send_app(r['src'],r['dst'],'Relay B' if r['relay']=='Relay A' else 'Relay A',r['label'],r['callback'])
 def reset(self,endpoint):
  self.log('endpoint_reset',endpoint)
  for c in list(self.all_conn):
   if not c['dead'] and endpoint in (c['src'],c['dst']):
    records=list(c['pending'])+[op['callback'] for op in c['data_ops'].values() if not op['callback']['applied']];c['dead']=True
    for r in records:self.at(self.t+1,self.send_app,r['src'],r['dst'],r['relay'],r['label'],r['callback'])
 def lock(self,account):
  def f():self.cash[account]-=25000;self.margin[account]+=25000
  self.change(f,'initial_margin_'+account);src='O_Mars' if account=='Mars_Factory' else 'O_Ceres'
  self.send_app(src,'O_Earth','Relay A','ORDER_LOCK_'+account,lambda:self.at(self.t+1,self.open_record,account))
 def open_record(self,account):
  self.order_locks.add(account)
  if len(self.order_locks)==2 and self.position=='not_open':self.position='open';self.metrics['open_hour']=self.t/3600;self.state('position_open')
 def price(self,h):
  p=100 if h==0 else (120 if h==240 else 125) if self.direction=='up' else (80 if h==240 else 75)
  self.log('publication','C_Ceres',observation_hour=h,price=p)
  self.at(self.t+1,self.send_app,'O_Ceres','O_Earth','Relay A',f'PRICE_{h}',lambda:self.at(self.t+1,self.mark,h,p))
 def mark(self,h,p):
  self.metrics[f'price_{h}_received']=self.t/3600
  if h==0:self.state('opening_price_received');return
  if h==240:
   self.metrics['mark_hour']=self.t/3600;self.metrics['interim_claim']=20000;self.state('interim_mark_backed_20000_not_spendable')
   dst='O_Ceres' if self.loser=='Ceres_Miner' else 'O_Mars'
   self.send_app('C_Earth',dst,'Relay B','MARGIN_CALL_20000',self.margin_call)
  else:self.settle()
 def margin_call(self):
  self.metrics['margin_call_received']=self.t/3600;self.at(self.t+1,self.topup)
 def topup(self):
  def f():self.cash[self.loser]-=20000;self.margin[self.loser]+=20000
  self.change(f,'topup_locked_20000');self.metrics['topup_locked']=self.t/3600
  src='O_Ceres' if self.loser=='Ceres_Miner' else 'O_Mars'
  self.send_app(src,'O_Earth','Relay A','TOPUP_LOCK_20000',lambda:self.at(self.t+1,self.topup_confirmed))
 def topup_confirmed(self):self.metrics['topup_confirmed']=self.t/3600;self.state('topup_recorded_at_clearing')
 def maturity(self):self.position='matured_pending_observation';self.state('maturity_observation_not_yet_received')
 def settle(self):
  # Standard funded runs: zero-equity trigger uses actual posted collateral.
  # The paper states standard 100->120->125 / 100->80->75 runs do not default.
  assert self.margin[self.loser]>=25000
  def f():self.margin[self.loser]-=25000;self.claim=25000;self.position='discharged_backed_claim'
  self.change(f,'final_total_25000_discharge_and_backed_claim');self.metrics['discharge_hour']=self.t/3600;self.metrics['backed_claim_hour']=self.t/3600
  for account in [self.loser,self.winner]:
   dst='O_Ceres' if account=='Ceres_Miner' else 'O_Mars'
   self.send_app('C_Earth',dst,'Relay B','SETTLE_PAY_'+account,lambda a=account:self.settlement_notice(a))
 def settlement_notice(self,account):
  def f():
   self.cash[account]+=self.margin[account];self.margin[account]=0
   if account==self.winner:self.cash[account]+=self.claim-10;self.cash['C_Earth_fee']+=10;self.claim=0
  self.change(f,'local_settlement_'+account);self.metrics['winner_notice' if account==self.winner else 'loser_notice']=self.t/3600;self.notifications.add(account)
  if len(self.notifications)==2:
   self.position='complete';self.metrics['spendable_hour']=self.t/3600;self.state('settlement_complete_both_local_updates')
 def run(self):
  self.at(-4*3600,self.get_conn,'O_Mars','O_Earth','Relay A');self.at(-4*3600,self.get_conn,'O_Ceres','O_Earth','Relay A')
  self.at(1,self.lock,'Mars_Factory');self.at(1,self.lock,'Ceres_Miner')
  for h in [0,240,480]:self.at(h*3600,self.price,h)
  self.at(480*3600,self.maturity,priority=0)
  if self.incident and self.incident['kind']=='reset':self.at(self.incident['start']*3600,self.reset,self.incident['node'],priority=0)
  while self.events:
   t,_,_,fn,args=heapq.heappop(self.events)
   if t>self.run_end:break
   self.t=t;fn(*args)
  if 'spendable_hour' not in self.metrics:raise RuntimeError('did not finish '+str(self.incident))
  self.metrics.update({'incident':self.incident,'maintenance':self.maintenance,'direction':self.direction,'final_cash':self.cash,'final_margin':self.margin,'final_claim':self.claim,'asset_hours_cash':self.asset_hours,'peak_encumbered_cash':self.peak,'capital_utilization':self.peak/220000,'originated_backbone_packets':len(self.origins),'total_backbone_launches':self.total_launch,'direct_packets':0,'forced_loss_launches':self.forced_losses,'hop_abandonments':self.abandoned,'max_queue_packets':self.max_queue,'max_unacknowledged_data':self.max_window,'max_rolling24_origins':max(sum(t-86400<x<=t for x,_,_ in self.origins) for t,_,_ in self.origins),'final_total_cash':sum(self.cash.values())})
  return self.metrics

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--data',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);ap.add_argument('--scan',action='store_true');args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True);g=Geometry(args.data)
 baseline=Sim(g,detail=True);bm=baseline.run();results={'baseline':bm};candidates=[]
 if args.scan:
  kinds=[('isolation',n,72) for n in NAMES[:9]]+[('forced',n,6) for n in NAMES]+[('reset',n,0) for n in END_NODE]
  for kind,node,duration in kinds:
   for start in range(0,481,6):
    incident={'kind':kind,'node':node,'duration':duration,'start':start}
    try:r=Sim(g,incident).run();candidates.append({'kind':kind,'node':node,'start':start,'duration':duration,'spendable_hour':r['spendable_hour'],'delay_vs_baseline_hours':r['spendable_hour']-bm['spendable_hour'],'asset_hours_cash':r['asset_hours_cash']})
    except (RuntimeError,AssertionError) as e:candidates.append({'kind':kind,'node':node,'start':start,'duration':duration,'error':str(e)})
  (args.output/'candidate_scan.json').write_text(json.dumps(candidates,indent=2))
  good=[r for r in candidates if 'spendable_hour' in r];top=sorted(good,key=lambda r:r['spendable_hour'],reverse=True)
  print('TOP CANDIDATES',json.dumps(top[:12],indent=2));print('ERRORS',len(candidates)-len(good))
  # Refine terminal-settlement timing at one-minute spacing and baseline
  # emission boundaries +/-1 ms, keeping the incident unannounced.
  starts={470+k/60 for k in range(15*60+1)}
  for row in baseline.launches:
   if 470<=row['emission_hour']<=485:
    starts.add(row['emission_hour']-0.001/3600)
    starts.add(row['emission_hour']+0.001/3600)
  for node in ['Earth','Mars','Ceres']:
   for start in sorted(starts):
    inc={'kind':'isolation','node':node,'duration':72,'start':start}
    r=Sim(g,inc).run();candidates.append({'kind':'isolation','node':node,'start':start,'duration':72,'spendable_hour':r['spendable_hour'],'delay_vs_baseline_hours':r['spendable_hour']-bm['spendable_hour'],'asset_hours_cash':r['asset_hours_cash']})
  (args.output/'candidate_scan.json').write_text(json.dumps(candidates,indent=2))
  top=sorted([r for r in candidates if 'spendable_hour' in r],key=lambda r:r['spendable_hour'],reverse=True)
  # Earth and Ceres tie on completion. Prefer Earth (higher capital-hours
  # and clearing-hub exposure), then the earliest equally bad minute tick.
  tied=[r for r in top if abs(r['spendable_hour']-top[0]['spendable_hour'])<1e-7]
  minute_earth=[r for r in tied if r['node']=='Earth' and abs(r['start']*60-round(r['start']*60))<1e-7]
  winner=min(minute_earth,key=lambda r:r['start']) if minute_earth else top[0]
  incident={k:winner[k] for k in ['kind','node','duration','start']}
  results['selection_scan_count']=len(candidates);results['selected_incident']=incident
  print('REFINED TOP',json.dumps(top[:6],indent=2))
 else:
  incident={'kind':'isolation','node':'Earth','duration':72,'start':482.75}

 for key,inc,maint,direction in [('baseline_no_maintenance',None,False,'up'),('stress',incident,True,'up'),('stress_no_maintenance',incident,False,'up'),('baseline_falling',None,True,'down'),('stress_falling',incident,True,'down')]:
  sim=Sim(g,inc,maint,direction,detail=True);results[key]=sim.run();(args.output/(key+'_events.json')).write_text(json.dumps(sim.logs,indent=2));(args.output/(key+'_financial.json')).write_text(json.dumps(sim.fin,indent=2));
  with (args.output/(key+'_launches.csv')).open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(sim.launches[0]));writer.writeheader();writer.writerows(sim.launches)
 (args.output/'baseline_financial.json').write_text(json.dumps(baseline.fin,indent=2));(args.output/'baseline_events.json').write_text(json.dumps(baseline.logs,indent=2))
 with (args.output/'baseline_launches.csv').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(baseline.launches[0]));writer.writeheader();writer.writerows(baseline.launches)
 (args.output/'summary.json').write_text(json.dumps(results,indent=2));print('SUMMARY',json.dumps(results,indent=2))
if __name__=='__main__':main()
