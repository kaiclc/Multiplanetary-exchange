# Gator Quant Hacks S2 reproducibility bundle

Conditional event simulation of the team's retained 11-institution design.
Earlier review concerns are taken as accepted under the user's instruction;
this is not a claim to have retrieved organizer clarifications.

## Run
Python 3.9+; simulation and verifier use standard library only.
From this extracted directory:

    python3 s2_simulation.py --data inputs --output rerun
    python3 S2_verify.py rerun

To repeat all 5,556 candidate runs and incident selection:

    python3 s2_simulation.py --data inputs --output rerun_scan --scan
    python3 S2_verify.py rerun_scan

Default incident is Earth gateway isolation [482.75,554.75) hours.
Every financial run resets to the declared opening balance sheet. Geometry
never resets within a run. The simulation drains transport events through
hour 650; cash encumbrance is integrated to complete financial recovery.
Full origins include setup from hour -4; Direct traffic is zero.

## Included evidence
S2_appendix.pdf: two-page stand-alone appendix, 10 pt minimum, one-inch margins.
S2_stress_test.md: longer editable write-up with account and obligation tables.
results/summary.json: six baseline/stress/maintenance/price-direction results.
results/candidate_scan.json: 5,556 candidate rows (zero failed evaluations).
results/*_financial.json: canonical funded state after each financial event.
results/*_launches.csv: every launch, including receipts, automatic retries,
    geometry, distance-dependent loss probability and incident-forced losses.
results/*_events.json: enqueue, publication, receipt, retry and application events.
results/verification.json: independent exported-trace checks.
inputs/: official frozen orbital_elements.json, network_model.json and README.
manifest.json: SHA-256 hashes for the code, input files and exported results.

## Declared implementation choices
Background random loss is suppressed; unannounced deterministic incident
loss is retained. These are conditional timings, not stochastic guarantees.
No session keepalives: new handshakes after seven-day inactivity are counted.
A carries feed/top-up records; B carries clearing calls and settlements.
Co-located local handoffs take one second as accepted in the retained paper.
Standard funded runs use actual posted equity after the top-up for default;
the interim mark is backing allocated within collateral, not a separate
cash payment. The unspecified $10 fee is paid by the winner from proceeds.
Settlement completion is the later local credit/debit and margin-release
update. Client spendability is the balance available at its home gateway;
no additional client acknowledgment is required. Institutions start empty;
fee reserve receives only the earned $10. Remaining institutions hold zero.
Shares never transact in this futures-only scenario: 1,000 at Mars_Seller,
200 at Neptune_Saver throughout. Only isolated futures scenario is modeled;
this is not full-market saturation testing or a production packet encoder.
Financial records/claims outlive sessions and failed packet copies.

Coarse selection: 31 incident configurations x 81 six-hour start times.
Refinement: 1,015 minute/event-boundary starts x three isolation nodes.
Earth and Ceres tie on completion; Earth is preferred for higher capital-hours
and both clearing channels. Earliest minute-grid tied Earth case is h482.75.
Selection is a tested maximum, not an all-continuous-time proof.

PDF generation (optional): build_s2_pdf.py additionally needs reportlab and
system DejaVu Sans fonts. It writes output/S2/S2_appendix.pdf; create this
output directory first. The supplied PDF is already generated and checked.
